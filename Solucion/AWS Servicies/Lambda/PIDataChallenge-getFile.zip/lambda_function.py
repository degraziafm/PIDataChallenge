
import boto3
import botocore
import os
import pandas
import requests

from io import StringIO


url = os.environ['URL']
region = os.environ['REGION']
csv_file_name = os.environ['CSV_FILE_NAME']
bucket_name = os.environ['BUCKET_NAME']


def aws_client(service):
    print('Making client for aws service, ', service)
    
    try:
        client = boto3.client(service, region_name = region)
        return client
    
    except botocore.exceptions.ClientError as error:
        print('error, conecction to aws service: ', error)
        raise error


def write_csv(df, file_name, bucket):
    print('Loading new data into s3 bucket')
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, header = True, index = False)
    s3_client = aws_client('s3')
    s3_client.put_object(Bucket = bucket, Body = csv_buffer.getvalue(), Key = file_name + '.csv')


def lambda_handler(event, context):
    urlData = requests.get(url).content
    df = pandas.read_csv(StringIO(urlData.decode('utf-8')))

    write_csv(df, csv_file_name, bucket_name)

