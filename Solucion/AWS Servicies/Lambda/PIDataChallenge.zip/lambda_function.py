import boto3
import botocore
import json
import mysql.connector
import os
import pandas

from datetime import datetime
from io import StringIO
from mysql.connector import errorcode


table_metadata = {
    'NAME': 'Unificado',
    'FIELDS': [
        'CHROM',
	    'POS',
	    'ID',
	    'REF',
	    'ALT',
	    'QUAL',
	    'FILTER',
	    'INFO',
	    'FORMA',
	    'MUESTRA',
	    'VALOR',
	    'ORIGEN',
	    'FECHA_COPIA',
        'RESULTADO'
    ]
}

	
def aws_client(service, region):
    print('Making client for aws service, ', service)
    
    try:
        client = boto3.client(service, region_name = region)

        return client
    
    except botocore.exceptions.ClientError as error:
        print('error, conecction to aws service: ', error)
        raise error


def read_csv(region, bucket, object):
    s3_client = aws_client('s3', region)
    
    print('Loading csv file: ', object)
    
    csv_obj = s3_client.get_object(Bucket = bucket, Key = object)
    body = csv_obj['Body']
    csv_string = body.read().decode('utf-8')
    
    return csv_string


def get_parameter_store(region):
    print('Get parameters for aws parameter store')
    
    ssm_client = aws_client('ssm', region)
    
    user = ssm_client.get_parameter(Name = '/RDS/MySQL/PIDataChallenge/User', WithDecryption = True)['Parameter']['Value']
    passwd = ssm_client.get_parameter(Name = '/RDS/MySQL/PIDataChallenge/Password', WithDecryption = True)['Parameter']['Value']
    host = ssm_client.get_parameter(Name = '/RDS/MySQL/PIDataChallenge/Host')['Parameter']['Value']
    db_name = ssm_client.get_parameter(Name = '/RDS/MySQL/PIDataChallenge/Database')['Parameter']['Value']
    
    db_access = {
        'user': user,
        'password': passwd,
        'host': host,
        'database': db_name
    }
    
    return db_access


def db_conn(data_access):
    print('Connecting to database')
    
    try:
        conn = mysql.connector.connect(**data_access)
        return conn

    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
        raise err


def build_insert_query(table_data):
    QUERY_TEMPLATE = "INSERT INTO {} ({}) VALUES({})"

    table_name = table_data['NAME']
    table_fields = ','.join(table_data['FIELDS'])

    string_parameters_list = []

    for _ in range(0, len(table_data['FIELDS'])):
        string_parameters_list.append('%s')

    string_parameters = ','.join(string_parameters_list)

    query = QUERY_TEMPLATE.format(table_name, table_fields, string_parameters)
    print('Query to execute: ', query)
    
    return query


def build_df(data, table):
    
    df = pandas.read_csv(StringIO(data), sep=',')
    df.columns = table['FIELDS']
            
    df['RANK'] = df.groupby(["ID", "MUESTRA", "RESULTADO"]).cumcount() + 1
    df = df[df['RANK'] == 1] 
    df = df.drop(['RANK'], axis=1)

    df['FECHA_COPIA'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    df = list(df.itertuples(index = False, name = None))

    print('The Dataframe is ready')

    return df


def exec_query(db, query, data):
    
    try:
        with db as db_conn, db_conn.cursor() as db_cursor:
            
            db_cursor.executemany(query, data)
            db_conn.commit()
            
            print('Query executed')

    except Exception as e:
        raise e

    finally:
        db.close()


def extraction(region, bucket, object):
    return read_csv(region, bucket, object)


def transformation(csv_data, table_metadata):
    return build_df(csv_data, table_metadata)
    

def load(table_metadata, region, df):
    query = build_insert_query(table_metadata)
    db_access = get_parameter_store(region)
    my_db_conn = db_conn(db_access)
    exec_query(my_db_conn, query, df)


def lambda_handler(event, context):
    
    event_js = json.loads(str(event).replace("'", '"'))
    print('event: ', event_js)
    
    region = event_js['Records'][0]['awsRegion']
    landing_bucket = event_js['Records'][0]['s3']['bucket']['name']
    object_key = event_js['Records'][0]['s3']['object']['key']

    csv_data = extraction(region, landing_bucket, object_key)

    df = transformation(csv_data, table_metadata)
    
    load(table_metadata, region, df)
   
    print('Execution finished.')